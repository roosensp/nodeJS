/**
 * Created with JetBrains WebStorm.
 * User: paulroosens
 * Date: 02/10/13
 * Time: 14:00
 * To change this template use File | Settings | File Templates.
 */

function Gun()
{

    this.cadence   = 5 ;
    this.puissance = 10 ;
    this.degat      = 1 ;


}
